#
# TABLE STRUCTURE FOR: hak_akses
#

DROP TABLE IF EXISTS `hak_akses`;

CREATE TABLE `hak_akses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keterangan` varchar(50) NOT NULL,
  `hak_akses` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `hak_akses` (`id`, `keterangan`, `hak_akses`) VALUES (1, 'Admin', 1);
INSERT INTO `hak_akses` (`id`, `keterangan`, `hak_akses`) VALUES (2, 'Pegawai', 2);


#
# TABLE STRUCTURE FOR: rw_jabatan
#

DROP TABLE IF EXISTS `rw_jabatan`;

CREATE TABLE `rw_jabatan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bulantahun` varchar(20) NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `nama_jabatan` varchar(50) NOT NULL,
  `honor_jabatan` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `rw_jabatan` (`id`, `bulantahun`, `id_pegawai`, `nama_jabatan`, `honor_jabatan`) VALUES (1, '092023', 38, 'Waka Kurikulum', 450000);
INSERT INTO `rw_jabatan` (`id`, `bulantahun`, `id_pegawai`, `nama_jabatan`, `honor_jabatan`) VALUES (2, '092023', 50, 'Admin Sosial Media', 150000);
INSERT INTO `rw_jabatan` (`id`, `bulantahun`, `id_pegawai`, `nama_jabatan`, `honor_jabatan`) VALUES (3, '092023', 37, 'Waka Kesiswaan', 300000);
INSERT INTO `rw_jabatan` (`id`, `bulantahun`, `id_pegawai`, `nama_jabatan`, `honor_jabatan`) VALUES (4, '092023', 37, 'Kepala Program Jurusan', 500000);
INSERT INTO `rw_jabatan` (`id`, `bulantahun`, `id_pegawai`, `nama_jabatan`, `honor_jabatan`) VALUES (5, '102023', 38, 'Waka Kurikulum', 450000);
INSERT INTO `rw_jabatan` (`id`, `bulantahun`, `id_pegawai`, `nama_jabatan`, `honor_jabatan`) VALUES (6, '102023', 42, 'Kepala Program Jurusan', 500000);
INSERT INTO `rw_jabatan` (`id`, `bulantahun`, `id_pegawai`, `nama_jabatan`, `honor_jabatan`) VALUES (7, '102023', 50, 'Admin Sosial Media', 150000);
INSERT INTO `rw_jabatan` (`id`, `bulantahun`, `id_pegawai`, `nama_jabatan`, `honor_jabatan`) VALUES (8, '102023', 37, 'Waka Kesiswaan', 300000);


#
# TABLE STRUCTURE FOR: rw_jam
#

DROP TABLE IF EXISTS `rw_jam`;

CREATE TABLE `rw_jam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bulantahun` varchar(20) NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `mapel` varchar(100) NOT NULL,
  `jumlah_jam` int(11) NOT NULL,
  `honor_perjam` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (1, '092023', 38, 'ASJ', 6, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (2, '092023', 50, 'Sejarah Indo Kelas 11', 5, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (3, '092023', 50, 'Prakarya Kewirausahaan Kelas 10', 5, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (4, '092023', 37, 'Sejarah Indo Kelas 10 A', 7, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (5, '092023', 37, 'Sejarah Indo Kelas 10 B', 7, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (6, '102023', 38, 'ASJ', 6, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (7, '102023', 42, 'Sejarah Indo Kelas 10 B', 7, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (8, '102023', 42, 'Matematika kelas 10', 5, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (9, '102023', 50, 'Sejarah Indo Kelas 11', 5, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (10, '102023', 50, 'Prakarya Kewirausahaan Kelas 10', 5, 20000);
INSERT INTO `rw_jam` (`id`, `bulantahun`, `id_pegawai`, `mapel`, `jumlah_jam`, `honor_perjam`) VALUES (11, '102023', 37, 'Sejarah Indo Kelas 10 A', 7, 20000);


#
# TABLE STRUCTURE FOR: tb_absensi
#

DROP TABLE IF EXISTS `tb_absensi`;

CREATE TABLE `tb_absensi` (
  `id_absen` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(11) NOT NULL,
  `bulantahun` varchar(15) NOT NULL,
  `hadir` int(11) NOT NULL,
  `izin` int(11) NOT NULL,
  `sakit` int(11) NOT NULL,
  `alfa` int(11) NOT NULL,
  PRIMARY KEY (`id_absen`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (19, 38, '082023', 20, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (20, 42, '082023', 20, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (21, 37, '082023', 15, 0, 5, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (23, 48, '082023', 20, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (24, 50, '082023', 20, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (25, 38, '092023', 15, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (26, 42, '092023', 0, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (27, 48, '092023', 0, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (28, 50, '092023', 0, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (29, 37, '092023', 20, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (31, 38, '102023', 4, 1, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (32, 42, '102023', 17, 1, 2, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (33, 48, '102023', 10, 0, 1, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (34, 50, '102023', 6, 0, 0, 0);
INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `bulantahun`, `hadir`, `izin`, `sakit`, `alfa`) VALUES (35, 37, '102023', 15, 0, 0, 0);


#
# TABLE STRUCTURE FOR: tb_arsip
#

DROP TABLE IF EXISTS `tb_arsip`;

CREATE TABLE `tb_arsip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bulantahun` varchar(20) NOT NULL,
  `idp` int(11) NOT NULL,
  `jarak_transport` varchar(50) NOT NULL,
  `honor_transport` int(11) NOT NULL,
  `status_walas` int(11) NOT NULL,
  `hadir` int(11) NOT NULL,
  `honor_walas` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (1, '092023', 38, '5 KM', 10000, 0, 15, 0);
INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (2, '092023', 42, '10 KM', 15000, 1, 0, 100000);
INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (3, '092023', 48, '10 KM', 15000, 0, 0, 0);
INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (4, '092023', 50, '10 KM', 15000, 0, 0, 0);
INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (5, '092023', 37, '5 KM', 10000, 1, 20, 100000);
INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (6, '102023', 38, '5 KM', 10000, 0, 4, 0);
INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (7, '102023', 42, '10 KM', 15000, 1, 17, 100000);
INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (8, '102023', 48, '10 KM', 15000, 0, 10, 0);
INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (9, '102023', 50, '10 KM', 15000, 0, 6, 0);
INSERT INTO `tb_arsip` (`id`, `bulantahun`, `idp`, `jarak_transport`, `honor_transport`, `status_walas`, `hadir`, `honor_walas`) VALUES (10, '102023', 37, '5 KM', 10000, 1, 15, 100000);


#
# TABLE STRUCTURE FOR: tb_honor_kegiatan
#

DROP TABLE IF EXISTS `tb_honor_kegiatan`;

CREATE TABLE `tb_honor_kegiatan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(11) NOT NULL,
  `bulantahun` varchar(15) NOT NULL,
  `nama_kegiatan` varchar(20) NOT NULL,
  `honor_kegiatan` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_honor_kegiatan` (`id`, `id_pegawai`, `bulantahun`, `nama_kegiatan`, `honor_kegiatan`) VALUES (27, 42, '092023', 'pembimbing prakerin', 200000);
INSERT INTO `tb_honor_kegiatan` (`id`, `id_pegawai`, `bulantahun`, `nama_kegiatan`, `honor_kegiatan`) VALUES (28, 37, '092023', 'a', 100000);
INSERT INTO `tb_honor_kegiatan` (`id`, `id_pegawai`, `bulantahun`, `nama_kegiatan`, `honor_kegiatan`) VALUES (29, 37, '092023', 'b', 50000);
INSERT INTO `tb_honor_kegiatan` (`id`, `id_pegawai`, `bulantahun`, `nama_kegiatan`, `honor_kegiatan`) VALUES (31, 38, '092023', 'Anbk SMP', 200000);


#
# TABLE STRUCTURE FOR: tb_honorjam
#

DROP TABLE IF EXISTS `tb_honorjam`;

CREATE TABLE `tb_honorjam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jenis` varchar(20) NOT NULL,
  `honor` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_honorjam` (`id`, `jenis`, `honor`) VALUES (1, 'per jam', 20000);
INSERT INTO `tb_honorjam` (`id`, `jenis`, `honor`) VALUES (2, 'walas', 100000);


#
# TABLE STRUCTURE FOR: tb_jabatan
#

DROP TABLE IF EXISTS `tb_jabatan`;

CREATE TABLE `tb_jabatan` (
  `id_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jabatan` varchar(100) NOT NULL,
  `honor_jabatan` int(11) NOT NULL,
  PRIMARY KEY (`id_jabatan`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_jabatan` (`id_jabatan`, `nama_jabatan`, `honor_jabatan`) VALUES (1, 'Kepala Sekolah', 1000000);
INSERT INTO `tb_jabatan` (`id_jabatan`, `nama_jabatan`, `honor_jabatan`) VALUES (2, 'Kepala Program Jurusan', 500000);
INSERT INTO `tb_jabatan` (`id_jabatan`, `nama_jabatan`, `honor_jabatan`) VALUES (3, 'Waka Kurikulum', 450000);
INSERT INTO `tb_jabatan` (`id_jabatan`, `nama_jabatan`, `honor_jabatan`) VALUES (4, 'Waka Kesiswaan', 300000);
INSERT INTO `tb_jabatan` (`id_jabatan`, `nama_jabatan`, `honor_jabatan`) VALUES (5, 'Waka Humas Hubin', 200000);
INSERT INTO `tb_jabatan` (`id_jabatan`, `nama_jabatan`, `honor_jabatan`) VALUES (15, 'Admin Sosial Media', 155000);


#
# TABLE STRUCTURE FOR: tb_jam_mengajar
#

DROP TABLE IF EXISTS `tb_jam_mengajar`;

CREATE TABLE `tb_jam_mengajar` (
  `id_jam` int(11) NOT NULL AUTO_INCREMENT,
  `nama_mapel` varchar(100) NOT NULL,
  `jumlah_jam` int(11) NOT NULL,
  PRIMARY KEY (`id_jam`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_jam_mengajar` (`id_jam`, `nama_mapel`, `jumlah_jam`) VALUES (1, 'Sejarah Indo Kelas 10 A', 7);
INSERT INTO `tb_jam_mengajar` (`id_jam`, `nama_mapel`, `jumlah_jam`) VALUES (2, 'Sejarah Indo Kelas 10 B', 7);
INSERT INTO `tb_jam_mengajar` (`id_jam`, `nama_mapel`, `jumlah_jam`) VALUES (3, 'Sejarah Indo Kelas 11', 5);
INSERT INTO `tb_jam_mengajar` (`id_jam`, `nama_mapel`, `jumlah_jam`) VALUES (5, 'Prakarya Kewirausahaan Kelas 10', 5);
INSERT INTO `tb_jam_mengajar` (`id_jam`, `nama_mapel`, `jumlah_jam`) VALUES (6, 'Matematika kelas 10', 5);
INSERT INTO `tb_jam_mengajar` (`id_jam`, `nama_mapel`, `jumlah_jam`) VALUES (7, 'ASJ', 6);


#
# TABLE STRUCTURE FOR: tb_pegawai
#

DROP TABLE IF EXISTS `tb_pegawai`;

CREATE TABLE `tb_pegawai` (
  `id_pegawai` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pegawai` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `id_transport` int(11) NOT NULL,
  `walas` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `username` varchar(120) NOT NULL,
  `password` varchar(120) NOT NULL,
  `hak_akses` int(11) NOT NULL,
  PRIMARY KEY (`id_pegawai`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_pegawai` (`id_pegawai`, `nama_pegawai`, `jenis_kelamin`, `alamat`, `id_transport`, `walas`, `image`, `username`, `password`, `hak_akses`) VALUES (37, 'nana gajah paling ngeselin', 'P', 'Land of down', 2, 1, '1695887560.png', 'nanas', '$2y$10$M1PA.cNcq7IQSWlSAXrlXOX/JcGjxLVkezFu1g14YPxpdZeLrapCe', 2);
INSERT INTO `tb_pegawai` (`id_pegawai`, `nama_pegawai`, `jenis_kelamin`, `alamat`, `id_transport`, `walas`, `image`, `username`, `password`, `hak_akses`) VALUES (38, 'AnjayaniYeah', 'L', 'tepi pantai', 2, 0, 'default_avatar.png', 'anjay', '$2y$10$hEg0UxWSq8BCS5DEYxLBUuuyV9Ek0etpakaPfvtsxBuaOgbj19N2W', 2);
INSERT INTO `tb_pegawai` (`id_pegawai`, `nama_pegawai`, `jenis_kelamin`, `alamat`, `id_transport`, `walas`, `image`, `username`, `password`, `hak_akses`) VALUES (42, 'Balmon', 'L', 'Wakanda', 3, 1, 'default_avatar.png', 'momon', '$2y$10$hEg0UxWSq8BCS5DEYxLBUuuyV9Ek0etpakaPfvtsxBuaOgbj19N2W', 2);
INSERT INTO `tb_pegawai` (`id_pegawai`, `nama_pegawai`, `jenis_kelamin`, `alamat`, `id_transport`, `walas`, `image`, `username`, `password`, `hak_akses`) VALUES (48, 'Kadita', 'P', 'Wakanda', 3, 0, '1695689166.png', 'kaditas', '$2y$10$PLGxSBLoWe/8xIC6yd/ts.wiHPd4gsCaEjVjOIR2dGVUPPYz19eBy', 1);
INSERT INTO `tb_pegawai` (`id_pegawai`, `nama_pegawai`, `jenis_kelamin`, `alamat`, `id_transport`, `walas`, `image`, `username`, `password`, `hak_akses`) VALUES (50, 'Ling Lung', 'L', 'Land of down', 3, 0, 'default_avatar.png', 'ling', '$2y$10$hEg0UxWSq8BCS5DEYxLBUuuyV9Ek0etpakaPfvtsxBuaOgbj19N2W', 2);
INSERT INTO `tb_pegawai` (`id_pegawai`, `nama_pegawai`, `jenis_kelamin`, `alamat`, `id_transport`, `walas`, `image`, `username`, `password`, `hak_akses`) VALUES (52, 'Molina', 'P', 'Land of down', 3, 0, '1695887408.png', 'molina', '$2y$10$hEg0UxWSq8BCS5DEYxLBUuuyV9Ek0etpakaPfvtsxBuaOgbj19N2W', 1);


#
# TABLE STRUCTURE FOR: tb_transport
#

DROP TABLE IF EXISTS `tb_transport`;

CREATE TABLE `tb_transport` (
  `id_transport` int(11) NOT NULL AUTO_INCREMENT,
  `jarak` varchar(30) NOT NULL,
  `honor_transport` int(11) NOT NULL,
  PRIMARY KEY (`id_transport`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_transport` (`id_transport`, `jarak`, `honor_transport`) VALUES (1, '0 KM', 0);
INSERT INTO `tb_transport` (`id_transport`, `jarak`, `honor_transport`) VALUES (2, '5 KM', 10000);
INSERT INTO `tb_transport` (`id_transport`, `jarak`, `honor_transport`) VALUES (3, '10 KM', 15000);


#
# TABLE STRUCTURE FOR: tmp_jabatan
#

DROP TABLE IF EXISTS `tmp_jabatan`;

CREATE TABLE `tmp_jabatan` (
  `id_tmp` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(11) NOT NULL,
  `id_jabatan` int(11) NOT NULL,
  `honor` int(11) NOT NULL,
  PRIMARY KEY (`id_tmp`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tmp_jabatan` (`id_tmp`, `id_pegawai`, `id_jabatan`, `honor`) VALUES (25, 37, 4, 300000);
INSERT INTO `tmp_jabatan` (`id_tmp`, `id_pegawai`, `id_jabatan`, `honor`) VALUES (35, 50, 15, 150000);
INSERT INTO `tmp_jabatan` (`id_tmp`, `id_pegawai`, `id_jabatan`, `honor`) VALUES (36, 52, 5, 200000);
INSERT INTO `tmp_jabatan` (`id_tmp`, `id_pegawai`, `id_jabatan`, `honor`) VALUES (37, 38, 3, 450000);
INSERT INTO `tmp_jabatan` (`id_tmp`, `id_pegawai`, `id_jabatan`, `honor`) VALUES (38, 42, 2, 500000);


#
# TABLE STRUCTURE FOR: tmp_jam
#

DROP TABLE IF EXISTS `tmp_jam`;

CREATE TABLE `tmp_jam` (
  `id_tmp` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(11) NOT NULL,
  `id_jam` int(11) NOT NULL,
  `jumlah_jam` int(11) NOT NULL,
  PRIMARY KEY (`id_tmp`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tmp_jam` (`id_tmp`, `id_pegawai`, `id_jam`, `jumlah_jam`) VALUES (109, 37, 1, 7);
INSERT INTO `tmp_jam` (`id_tmp`, `id_pegawai`, `id_jam`, `jumlah_jam`) VALUES (111, 50, 3, 5);
INSERT INTO `tmp_jam` (`id_tmp`, `id_pegawai`, `id_jam`, `jumlah_jam`) VALUES (112, 50, 5, 5);
INSERT INTO `tmp_jam` (`id_tmp`, `id_pegawai`, `id_jam`, `jumlah_jam`) VALUES (115, 38, 7, 6);
INSERT INTO `tmp_jam` (`id_tmp`, `id_pegawai`, `id_jam`, `jumlah_jam`) VALUES (118, 42, 2, 7);
INSERT INTO `tmp_jam` (`id_tmp`, `id_pegawai`, `id_jam`, `jumlah_jam`) VALUES (119, 42, 6, 5);


